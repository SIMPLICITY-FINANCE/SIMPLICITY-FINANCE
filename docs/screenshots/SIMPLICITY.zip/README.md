
  # SIMPLICITY

  This is a code bundle for SIMPLICITY. The original project is available at https://www.figma.com/design/VVET7kgR20gn6GmvJJS9CV/SIMPLICITY.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  