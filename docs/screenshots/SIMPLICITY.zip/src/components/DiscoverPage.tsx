export { PodcastCatalog as DiscoverPage } from './PodcastCatalog';
