export { NotificationsList as NotificationsPage } from './NotificationsList';
