export { Feed as HomePage } from './Feed';
