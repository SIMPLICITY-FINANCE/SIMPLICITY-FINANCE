export { NewShowsList as NewShowsPage } from './NewShowsList';
