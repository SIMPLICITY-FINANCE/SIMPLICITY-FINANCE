export { TopPeopleList as TopPeoplePage } from './TopPeopleList';
